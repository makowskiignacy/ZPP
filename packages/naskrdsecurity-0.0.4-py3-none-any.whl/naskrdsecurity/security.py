import logging

from keycloak import KeycloakOpenID, exceptions

from naskrdsecurity.flask_restx_tools.custom_exceptions import AuthorizationError, ExternalServiceConnectionError

logger = logging.getLogger(__name__)


class KeycloakClient:
    """
    Client for KeycloakOpenID.
    """
    def __init__(self, keycloak_address, realm, client_id, username: str, password: str) -> None:
        """
        :param: keycloak_address: keycloak address e.g. auth.rd.nask.pl
        :param: realm: keycloak realm e.g. ML-PLATFORM
        :param: client_id: keycloak client_id e.g. ml_platform
        :param: username: keycloak username for user registered in keycloak e.g. test
        :param: password: keycloak user password e.g. test
        """
        self.keycloak_address = keycloak_address
        self.realm = realm
        self.client_id = client_id
        self._username = username
        self._password = password
        self._keycloak_client = None
        self._response_data = None
        self._auth_header = None

    def _create_basic_url(self) -> str:
        """
        Creating authentication server url

        :return string with url
        """
        protocol = "http://" if "localhost" in self.keycloak_address else "https://"
        return f'{protocol}{self.keycloak_address}/auth/'

    def _client(self, username, password) -> KeycloakOpenID:
        """ Instance of KeycloakOpenID """
        try:
            if self._keycloak_client is None:
                self._keycloak_client = KeycloakOpenID(server_url=self._create_basic_url(),
                                                       client_id=self.client_id,
                                                       realm_name=self.realm)
            if self._response_data is None:
                self._response_data = self._keycloak_client.token(username=username,
                                                                  password=password)
            return self._keycloak_client
        except exceptions.KeycloakAuthenticationError as e:
            raise AuthorizationError(f'Wrong authorization data (username, or password)')
        except (exceptions.KeycloakGetError, exceptions.KeycloakConnectionError) as e:
            error_name = type(e).__name__
            raise ExternalServiceConnectionError(f'Connection error ({error_name})')

    def _create_keycloak_session_auth_header(self, username, password) -> dict:
        """
        Create keycloak client and generate authorization dict

        :param username: username (str)
        :param password: password (str)
        :return authorization header (add to request param e.g. request.get(url=url, headers=<returned_data>)
        """
        self._client(username, password)
        bearer = 'Bearer'
        access_token = self._response_data.get('access_token', '')
        return {'Authorization': f'{bearer} {access_token}'}

    def _create_session(self):
        """ Create keycloak session. """
        self._auth_header = self._create_keycloak_session_auth_header(username=self._username,
                                                                      password=self._password)

    def _close_session(self) -> None:
        """ Close keycloak session. """
        self._auth_header = None
        self._response_data = None

    def create_connection(self, url, func, **kwargs):
        """
        Create connection in security session.

        :param url: url to ML-Platform endpoint (str)
        :param func: requests function (e.g. requests.post) (str)
        :return response
        """
        self._create_session()
        response = func(url=url, headers=self._auth_header, **kwargs)
        self._close_session()
        return response
