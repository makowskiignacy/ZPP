"""
NASK-rd-security (naskrdsecurity) package is required to connect to API endpoints secured
with the nask keycloak security system.

Example of use:

- Without package:

    response = requests.post(url='some_url',
                             params={'some_param_key': 'some_param_value'})

- Package application example:

    keycloak_client = KeycloakClient(keycloak_address, realm, client_id, username: str, password: str)

    response = keycloak_client.create_connection(url='some_url',
                                                 func=requests.post,
                                                 params={'some_param_key': 'some_param_value'})
"""
import logging

from naskrdsecurity.flask_restx_tools.parsers import authorization_parser
from naskrdsecurity.security import KeycloakClient
from naskrdsecurity.manager import SecurityManager

logging.basicConfig(level=logging.INFO)
