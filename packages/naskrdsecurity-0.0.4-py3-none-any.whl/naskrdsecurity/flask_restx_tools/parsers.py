from flask_restx import reqparse

def authorization_parser() -> reqparse.RequestParser:
    """
    Parameters for user authorization.

    :return: request parameters parser
    """
    parser = reqparse.RequestParser()

    parser.add_argument('Authorization',
                        type=str,
                        location='headers',
                        required=False,
                        default='Bearer ',
                        trim=True,
                        help='Authorization token.')
    return parser
