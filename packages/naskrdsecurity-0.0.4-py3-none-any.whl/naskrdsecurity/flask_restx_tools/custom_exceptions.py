class BaseError(Exception):
    """ Base service later error. """

    def __init__(self, error_message: str) -> None:
        """
        :param error_message: customized error messages
        """
        self.error_message = error_message

    def __str__(self) -> str:
        return self.error_message


class AuthenticationError(BaseError):
    """ Exception raised when the user fails to authenticate. """


class AuthorizationError(BaseError):
    """ Exception raised when the user is not authorized for the requested action. """


class ExternalServiceConnectionError(BaseError):
    """ Exception raised when the connection to an external service is disrupted. """
