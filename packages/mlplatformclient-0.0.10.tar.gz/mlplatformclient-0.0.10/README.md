# ml-platform-client

Ml-platform client. [source of code](https://gitlab.cbitt.nask.pl/zis/ml-platform-client) is on gitlab.

### Generate package and install locally

- Install `requirements.txt`
  ```
  pip3 install -r requirements.txt
  ```
- Run sh `generate_package.sh`
- Install package from *.tar.gz file:
  ```
  pip3 install <package_name>.tar.gz
  ```

### Generate and register package (gitlab-ci)

- Set environment variables `CI_JOB_TOKEN_NAME` and `CI_JOB_TOKEN` [(documentation)](https://docs.gitlab.com/ee/user/project/deploy_tokens/index.html)
- Set package version (`pyproject.toml -> [project] -> version`)
- Push to gitlab (origin)
- Build Gitlab CI

### Install package from terminal

- Generate Personal Access Token in Gitlab UI [(documentation)](https://docs.gitlab.com/ee/user/profile/personal_access_tokens.html#create-a-personal-access-token)
- pip3 install mlplatformclient --index-url https://<personal_token_name>:<your_personal_token>@gitlab.cbitt.nask.pl/api/v4/projects/190/packages/pypi/simple
- <your_personal_token> is [GITLAB_PIP_TOKEN](https://docs.gitlab.com/ee/user/profile/personal_access_tokens.html)

### Install package by requirements.txt file from Gitlab Package Registry

- Generate Personal Access Token in Gitlab UI [(GITLAB_PIP_TOKEN)](https://docs.gitlab.com/ee/user/profile/personal_access_tokens.html#create-a-personal-access-token)
- Set environment variables `PIP_EXTRA_INDEX_URL` with following code:
  ```
  https://__token__:<GITLAB_PIP_TOKEN>@gitlab.cbitt.nask.pl/api/v4/projects/190/packages/pypi/simple
  ```
  Important: Change `<GITLAB_PIP_TOKEN>` to the access token generated in the first step.
- Add following code to requirements.txt file (remember to set package version!):
  ```
  mlplatformclient~=<version>
  ```
- pip3 install -r requirements.txt