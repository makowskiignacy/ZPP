import os
import logging
import requests
import shutil
import time

from naskrdsecurity.security import KeycloakClient

from mlplatformclient.utils import handle_connection_error

WAIT_TIME_FOR_DATASET = 2
logger = logging.getLogger(__name__)


class MLPlatformClient:
    """
    Client for ML-Platform
    """
    def __init__(self, ml_platform_address: str, keycloak_address: str, realm: str, client_id: str, username: str,
                 password: str) -> None:
        """
        :param: ml_platform_address: ml-platform address e.g. 127.0.0.1:5000
        :param: keycloak_address: keycloak address e.g. auth.rd.nask.pl
        :param: realm: keycloak realm e.g. ML-PLATFORM
        :param: client_id: keycloak client_id e.g. ml_platform
        :param: username: keycloak username for user registered in keycloak e.g. test
        :param: password: keycloak user password e.g. test
        """
        self.ml_platform_address = ml_platform_address
        self.base_url = f'https://{self.ml_platform_address}/api/experiment-runner'
        self.keycloak_client = KeycloakClient(keycloak_address, realm, client_id, username, password)

    @staticmethod
    def _verify_path(name: str, path: str = None):
        if path:
            path = os.path.abspath(path)
            if not os.path.exists(path):
                os.makedirs(path)
            return os.path.join(path, f'{name}.zip')
        else:
            return f'/tmp/{name}.zip'

    def _save_file(self, response, name: str, path: str = None):
        file_path = self._verify_path(name=name, path=path)
        if os.path.isfile(file_path):
            logger.warning(f"The file already exists in this location '{file_path}'")
        elif response.status_code == 200:
            with open(file_path, 'wb') as file:
                shutil.copyfileobj(response.raw, file)
            logger.info(f"The file with downloaded model saved successfully '{file_path}'")
            return {'file_name': name, 'file_path': file_path}
        else:
            logger.error(f"Unexpected error. Possible that ML-Platform experiment exist without mlflow registration "
                         f"or mlflow artifacts. Response status code: {response.status_code}")
            return {}

    @staticmethod
    def _file_path_generator(name: str, path: str) -> str:
        full_path = os.path.abspath(path)
        os.makedirs(full_path, exist_ok=True)
        file_name = name if name[-4:] == ".csv" else f"{name}.csv"
        return os.path.join(full_path, file_name)

    def _save_dataset_file(self, response, name: str, path: str):
        file_path = self._file_path_generator(name=name, path=path)
        if response.status_code == 200:
            with open(file_path, 'wb') as file:
                shutil.copyfileobj(response.raw, file)
            logger.info(f"The file with dataset saved successfully '{file_path}'")
            return {'file_name': name, 'file_path': file_path}
        else:
            message = f"Unexpected error. Response status code: {response.status_code}"
            logger.error(message)
            return {"message": message}

    @handle_connection_error('ml-platform')
    def experiment_progress(self, experiment_id: str) -> dict:
        """
        Request to ML-Platform

        :param experiment_id: id of experiment (str)
        :return response data dict
        """
        response = self.keycloak_client.create_connection(url=f'{self.base_url}/experiments/{experiment_id}',
                                                          func=requests.get)
        return response.json()

    @handle_connection_error('ml-platform')
    def create_experiment(self, config_file: str) -> dict:
        """
        Request to ML-Platform

        :param config_file: path to file (str)
        :return response data dict
        """
        with open(config_file, 'rb') as file:
            response = self.keycloak_client.create_connection(url=f'{self.base_url}/experiments',
                                                              func=requests.post,
                                                              files={'config': file})
        return response.json()

    @handle_connection_error('ml-platform')
    def test_experiment(self) -> dict:
        """
        Request to ML-Platform

        :return: response data dict
        """
        response = self.keycloak_client.create_connection(url=f'{self.base_url}/experiments/test',
                                                          func=requests.post)
        return response.json()

    @handle_connection_error('ml-platform')
    def get_compressed_artifacts(self, mlflow_experiment_name: str, mlflow_run_name: str,
                                 zip_destination_path: str = None) -> dict:
        """
        Request to ML-Platform. Downloading zipped file with model artifacts.

        :param: zip_destination_path: Optional. Path to downloaded files (str)
        :param: mlflow_experiment_name: Name of experiment [mlflow] (str)
        :param: mlflow_run_name: Name of run [mlflow] (str)
        :return str: {'file_name': name, 'file_path': file_path}
        """
        response = self.keycloak_client.create_connection(
            url=f'{self.base_url}/models/{mlflow_experiment_name}/{mlflow_run_name}',
            func=requests.get,
            stream=True)
        name = f'{mlflow_experiment_name}_{mlflow_run_name}'
        return self._save_file(response=response, name=name, path=zip_destination_path)

    @handle_connection_error('ml-platform')
    def get_experiments_list(self, user_id, experiment_name, page_number=1, page_size=5) -> dict:
        """
        Request to ML-Platform. Get filtered by user_id and experiment_name list of experiments.

        :param: user_id: Id of user (str)
        :param: experiment_name: Experiment name (str)
        :param: page_number: Optional. number of page (int)
        :param: page_size: Optional. Number of items on page (int)
        :return: response data dict
        """
        response = self.keycloak_client.create_connection(url=f'{self.base_url}/experiments',
                                                          func=requests.get,
                                                          params={'user_id': user_id,
                                                                  'experiment_name': experiment_name,
                                                                  'page_number': page_number,
                                                                  'page_size': page_size})
        return response.json()

    @handle_connection_error('ml-platform')
    def register_dataset(self, source_path: str) -> dict:
        """
        Request to ML-Platform. Register dataset from Nextcloud.

        :param: source_path: path to file in Nextcloud (str)
        :return: response data dict
        """
        response = self.keycloak_client.create_connection(url=f'{self.base_url}/datasets/nextcloud',
                                                          func=requests.post,
                                                          params={'source_path': source_path})
        return response.json()

    @handle_connection_error('ml-platform')
    def get_dataset(self, dataset_id: str, file_name: str, destination_path: str) -> dict:
        """
        Request to ML-Platform. Downloading zipped file with model artifacts.

        :param: dataset_id: id of dataset you want to download
        :param: file_name: Own name for file.
        :param: destination_path: Path to location you want to save file.
        :return str: {'file_name': name, 'file_path': file_path}
        """
        response = self.keycloak_client.create_connection(
            url=f'{self.base_url}/datasets/{dataset_id}/file',
            func=requests.get,
            stream=True)
        return self._save_dataset_file(response=response, name=file_name, path=destination_path)

    @handle_connection_error('ml-platform')
    def dataset_datails(self, dataset_id: str) -> dict:
        """
        Request to ML-Platform. Check details about dataset.

        :param: dataset_id: id of dataset
        :return: response data dict
        """
        response = self.keycloak_client.create_connection(url=f'{self.base_url}/datasets/{dataset_id}',
                                                          func=requests.get)
        return response.json()

    def register_dataset_and_check_upload(self, source_path: str) -> dict:
        """
        Request to ML-Platform. Register dataset from Nextcloud and wait for register.

        :param: source_path: path to file in Nextcloud (str)
        :return: response data dict
        """
        upload_data = self.register_dataset(source_path)
        while True:
            result = self.dataset_datails(upload_data['id'])
            if result['uploaded'] == False:
                logger.error(f'Upload file error: {result}')
                return False
            elif result['uploaded']:
                logger.info(f'Successfully upload file: {result}')
                break
            logger.warning(f'Wait time for upload dataset {WAIT_TIME_FOR_DATASET} seconds.')
            time.sleep(WAIT_TIME_FOR_DATASET)
        return result
