import os.path
import logging
import subprocess
import sys

import mlflow
import mlflow.sklearn

from mlplatformclient.custom_exceptions import InvalidArgumentError

logger = logging.getLogger(__name__)


class SklearnObject:
    """
    this class is for deserialization of sklearn objects
    """
    def __init__(self, files_path):
        self.files_path = files_path
        self.model_or_pipeline = None

    @staticmethod
    def install_packages(requirements_path_or_package_name: str) -> None:
        """
        Install packages using name or requirements.txt file.

        :param: requirements_path_or_package_name: Path to requirements.txt file or package name e.g. 'scikit-learn'
        """
        if os.path.exists(requirements_path_or_package_name):
            if os.path.basename(requirements_path_or_package_name) == 'requirements.txt':
                subprocess.check_call([sys.executable, '-m', 'pip', 'install', '-r', requirements_path_or_package_name])
        else:
            subprocess.check_call([sys.executable, '-m', 'pip', 'install', requirements_path_or_package_name])

    @staticmethod
    def _requirements_path(base_path: str) -> str:
        base_path = os.path.abspath(base_path)
        return os.path.join(base_path, 'requirements.txt')

    def _deserialization_model(self):
        if not self.model_or_pipeline:
            requirements = self._requirements_path(self.files_path)
            if os.path.exists(requirements):
                self.install_packages(requirements)
                self.model_or_pipeline = mlflow.sklearn.load_model(self.files_path)
                logger.info("Model is deserialized from artifacts")
                return self.model_or_pipeline
            raise InvalidArgumentError(f"Source file path argument: "
                                       f"{self.files_path} in deserialization_model() is invalid.")
        return self.model_or_pipeline

    def get_deserialized_model_or_pipeline(self):
        """
        Return sklearn model e.g. StandardScaler or Pipeline.

        :return: return sklearn model e.g. StandardScaler or Pipeline
        """
        return self._deserialization_model()

