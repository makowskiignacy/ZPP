"""
The mlplatformclient package contains the basic tools enabling communication with the ML-Platform API.

Tools available in the package:

- MLPlatformClient [import]: from mlplatformclient import MLPlatformClient

    ml_platform = MLPlatformClient(ml_platform_address, keycloak_address, realm, client_id, username, password)
            :param: ml_platform_address: ml-platform address e.g. 127.0.0.1:5000  (str)
            :param: keycloak_address: keycloak address e.g. auth.rd.nask.pl (str)
            :param: realm: keycloak realm e.g. ML-PLATFORM (str)
            :param: client_id: keycloak client_id e.g. ml_platform (str)
            :param: username: keycloak username for user registered in keycloak e.g. test (str)
            :param: password: keycloak user password e.g. test (str)
        return: MLPlatformClient instance

    experiment = ml_platform.create_experiment(config_file=<EXPERIMENT_CONFIG_FILE.XML>)
        Creates an experiment in ML-Platform with EXPERIMENT_CONFIG_FILE.XML specification.
        return: {
              "id": "string",
              "name": "string",
              "description": "string",
              "user_id": "string",
              "group_id": "string",
              "submit_date": "2022-09-26T15:08:03.525Z",
              "status": "string",
              "quality_indicator": "string",
              "ml_flow_exp_id": "string"
            }

    experiment_info = ml_platform.experiment_progress(experiment_id=<EXPERIMENT_ID>)
        Checks the progress of the experiment with the given EXPERIMENT_ID
        return {
              "id": "string",
              "name": "string",
              "description": "string",
              "user_id": "string",
              "group_id": "string",
              "submit_date": "2022-09-26T15:09:43.231Z",
              "status": "string",
              "quality_indicator": "string",
              "ml_flow_exp_id": "string"
            }

    experiment_info = ml_platform.register_dataset(source_path=<path_ON_CLOUD>)
        Register dataset from Cloud in Ml-platform using source_path (location on Cloud).
        return {
              "id": "string",
              "file_name": "string",
              "user_id": "string",
              "group_id": "string",
              "source": "string",
              "source_kwargs": {
                "source_path": "string"
              },
              "upload_date": "2023-03-21T06:49:41.827Z",
              "uploaded": true,
              "error_message": "string"
            }

    dataset = ml_platform.get_dataset(dataset_id=<DATASET_ID>, file_name=<CUSTOM_FILE_NAME>,
                                              destination_path=<DESTINATION_PATH>)
        Downloading dataset by DATASET_ID and located it to DESTINATION_PATH, add CUSTOM_FILE_NAME for downloaded file
        return {
                "file_name": "name",
                "file_path": "file_path"
                }

    model_artifacts = ml_platform.get_compressed_artifacts(run_id=<RUN_ID>, zip_destination_path=<BASE_PATH>)
        Downloading the created model by RUN_ID and located it to BASE_PATH
        return {
                "file_name": "name",
                "file_path": "file_path"
                }


- NextCloud [import]: from mlplatformclient import NextCloud

    next_cloud = NextCloud(host, user, password)
            :param: host: Nextcloud address e.g. nextcloud.nask.pl (str)
            :param: user: Nextcloud username e.g. test (str)
            :param: password: Nextcloud user password e.g. test (str)
        return: NextCloud instance

    next_cloud.upload_file(local_file_path=<PATH_TO_FILE>, remote_dir=<DIR_ON_CLOUD>)
        Method to send file to Cloud
        return boolean value (True if send).


- Unzipper [import]: from mlplatformclient import unzip

    unzip(source_path_file=model_artifacts['file_path'], destination_path=<PATH_FOR_UNPACKED_ARTIFACTS>)
        Model taken from ML-Platform Api is in ZIP compressed form. After downloading, you need to unpack the file.
        If the model is unpacked (model_name.pkl), this step should be skipped
        source_path_file is the path to downloaded model
        destination_path is the path where model should be unpacked
        return True if files has been extracted.


- SklearnObject [import]: from mlplatformclient import SklearnObject

    sklearn_instance = SklearnObject(files_path=<PATH_FOR_UNPACKED_ARTIFACTS>)
        Model_name.pkl is the model file that has been serialized by mlflow.
        You must specify the path model_name.pkl (and any additional files,
        such as requirements.txt, that must be in the same location)
        files_path is te path to model_name.pkl and additional files like requirements.txt
            (both file in the same location)

    pipeline = sklearn_instance.get_deserialized_model_or_pipeline()
        If you want to use the model, you should deserialize the model.
        return sklearn model or pipeline


- KeycloakClient [import]: from mlplatformclient import KeycloakClient

    KeycloakClient is automatically used by MLPlatformClient and does not need to be implemented.

"""
import logging

from mlplatformclient.ml_platform import MLPlatformClient
from mlplatformclient.mlflow_deserialization import SklearnObject
from mlplatformclient.nextcloud import NextCloud
from mlplatformclient.unzipper import unzip

logging.basicConfig(level=logging.INFO)
