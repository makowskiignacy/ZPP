from functools import reduce

from flask_restx import reqparse

def get_parsed_args(*parsers: reqparse.RequestParser) -> dict:
    """
    Filters request arguments so that no unexpected arguments appears.
    It also validates filtered arguments.

    :param parsers: request parser used for parsing request parameters
    :return: parsed arguments
    """
    return reduce(lambda a, b: {**a, **b.parse_args()}, [dict(), *parsers])
