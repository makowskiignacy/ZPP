import logging
from functools import wraps
from typing import Callable, Optional

import jwt
from keycloak import exceptions, KeycloakOpenID

from naskrdsecurity.flask_restx_tools.custom_exceptions import AuthenticationError, AuthorizationError, \
    ExternalServiceConnectionError
from naskrdsecurity.flask_restx_tools.parsers import authorization_parser
from naskrdsecurity.flask_restx_tools.utils import get_parsed_args

class SecurityManager:
    """
    Class for managing endpoints' authentication and authorization.

    Permissions example:
    permissions = {endpoint.get: RESOURCE_READ
                   endpoint.put: RESOURCE_UPDATE
                   endpoint.patch: RESOURCE_UPDATE
                   endpoint.post: RESOURCE_UPDATE}
    """

    def __init__(self, permissions: dict, keycloak_address: str, realm: str, client_id: str) -> None:
        """
        :param permissions: dictionary with permission endpoints
        :param keycloak_address: address of keycloak server
        :param realm: name of keycloak realm
        :param client_id: keycloak client_id
        """
        self.logger = logging.getLogger(__name__)
        self._permissions = permissions
        self.keycloak_address = keycloak_address
        self.realm = realm
        self.client_id = client_id

        self.protocol = "http://" if "localhost" in self.keycloak_address else "https://"
        url = f'{self.protocol}{self.keycloak_address}/auth/realms/{self.realm}/protocol/openid-connect/certs'
        self._jwks_client = jwt.PyJWKClient(url)

    @property
    def jwks_client(self) -> jwt.PyJWKClient:
        return self._jwks_client

    def verify_token(self, is_user_data_required: bool = False, endpoint: Optional[str] = None) -> Callable:
        """
        Decorator for testing whether the HTTP request made to a view
        function contains proper JWT token in the header, allowing
        for user authentication and authorization.

        :param is_user_data_required:
        :param endpoint: endpoint name used to locate required
                         permission in the config
        """
        def decorate(f) -> Callable:
            @wraps(f)
            def wrapper(*args, **kwargs):

                token = self._extract_token()

                # Authentication:
                decoded_token = self._decode_token(token)

                # Authorization:
                # TODO: remove if statement?
                if endpoint is not None:
                    required_permission = self._permissions.get(f'{endpoint}.{f.__name__}')
                    if required_permission not in self._extract_permissions(decoded_token):
                        raise AuthorizationError('User is not authorized for this action')
                else:
                    self.logger.warning(f'Authorization for the `{f.__name__}` endpoint is off')

                if is_user_data_required:
                    user_data = {
                        'user_name': decoded_token.get('preferred_username'),
                        'name': decoded_token.get('name'),
                        'email': decoded_token.get('email')
                    }
                    return f(user_data=user_data, *args, **kwargs)
                else:
                    return f(*args, **kwargs)
            return wrapper
        return decorate

    @staticmethod
    def _extract_token() -> str:
        """
        Gets JWT token from the header.

        :raises: AuthenticationError
        """
        authorization_args = get_parsed_args(authorization_parser())
        auth_header = authorization_args['Authorization']
        token = auth_header[7:] if auth_header.startswith('Bearer') else auth_header
        if not token:
            raise AuthenticationError(f'Brak tokenu')
        return token

    def _decode_token(self, token: str) -> dict:
        """
        Decodes and verifies provided JWT token. If token is invalid,
        expired, etc. it aborts with the HTTP code 401.

        :return: decoded token
        :raises: AuthenticationError
        """
        try:
            signing_key = self.jwks_client.get_signing_key_from_jwt(token)
            return jwt.decode(
                token,
                signing_key.key,
                audience="account",
                algorithms=["RS256"],
                verify=True,
                options={"verify_signature": True, "verify_aud": True}
            )
        except jwt.exceptions.PyJWTError as e:
            self.logger.warning(e)
            error_name = type(e).__name__
            raise AuthenticationError(f'Błąd walidacji tokenu ({error_name})')

    @staticmethod
    def _extract_permissions(decoded_token: dict) -> list:
        """
        Extracts list of permissions from the token.

        :param decoded_token: validated and decoded token
        """
        # TODO swap roles for permissions
        try:
            roles = decoded_token['realm_access']['roles']
            if isinstance(roles, list):
                return roles
            else:
                raise TypeError
        except (KeyError, TypeError):
            return []

    def get_access_token(self, username: str, password: str) -> str:
        """
        Returns keycloak access token for the user.

        :param username: user name
        :param password: user password
        """
        try:
            server_url = f'{self.protocol}{self.keycloak_address}/auth/'
            keycloak_openid = KeycloakOpenID(server_url=server_url,
                                             client_id=self.client_id,
                                             realm_name=self.realm)
            token = keycloak_openid.token(username=username, password=password)
            return token.get('access_token')
        except exceptions.KeycloakAuthenticationError as e:
            raise AuthorizationError(f'Wrong authorization data (username, or password)')
        except (exceptions.KeycloakGetError, exceptions.KeycloakConnectionError) as e:
            error_name = type(e).__name__
            raise ExternalServiceConnectionError(f'Connection error ({error_name})')
