import logging
import os

import owncloud
import zipfile

logger = logging.getLogger(__name__)


class NextCloud:
    """
    Client for ownCloud/nextCloud.

    Configuration example:
        [NEXTCLOUD]
        host: env, $[NEXTCLOUD_HOST:nextcloud.cbitt.nask.pl]
        user: env, $[NEXTCLOUD_USER:username]
        password: env, $[NEXTCLOUD_PASSWORD:pass]

    TODO: owncloud.owncloud.HTTPResponseError, requests.exceptions.ConnectTimeout and some more
    """

    def __init__(self, host: str, user: str, password: str) -> None:
        self._host = host
        self._user = user
        self._password = password
        self._client = None

    @property
    def client(self) -> owncloud.Client:
        """ Instance of the owncloud.Client. """
        if self._client is None:
            self._client = owncloud.Client(self._host)
            self._client.login(self._user, self._password)
        return self._client

    def upload_file(self, local_file_path, remote_dir) -> bool:
        """
        Uploads file to the storage. The remote file path is concatenation of user directory path and remote dir path.
        File name is preserved.

        :param local_file_path: path to file that is to be uploaded
        :type local_file_path: str
        :param remote_dir: remote dir (relative to user directory)
        :type remote_dir: str
        :return if the operation was successful
        """
        return self.client.put_file(f'{remote_dir}/{os.path.basename(local_file_path)}', local_file_path)

    def download_file(self, remote_path: str, local_dir: str) -> bool:
        """
        Downloads requested file from the storage. File name is preserved.

        :param remote_path: path to the file to download
        :param local_dir: path of directory to save file in
        :return: if the operation was successful
        """
        os.makedirs(local_dir, exist_ok=True)
        local_file = os.path.join(local_dir, os.path.basename(remote_path))
        return self.client.get_file(remote_path, local_file)

    def delete_file(self, remote_path) -> bool:
        """
        Removes file from the storage.

        :param remote_path: path of file to delete
        :type remote_path: str
        :return if the operation was successful
        """
        return self.client.delete(remote_path)

    def download_directory(self, remote_path, local_dir) -> bool:
        """
        Downloads contents of the remote directory
        :param remote_path: path to directory to be downloaded
        :param local_dir: Path to local directory
        """
        dirname = os.path.basename(remote_path)
        local_name = os.path.join(local_dir, f'{dirname}.zip')

        os.makedirs(local_dir, exist_ok=True)
        if not self.client.get_directory_as_zip(remote_path, local_name):
            return False
        with zipfile.ZipFile(local_name, 'r') as zipped:
            zipped.extractall(local_dir)
            unzipped_dir = os.path.join(local_dir, dirname)
            logger.info(f'Downloaded files {os.listdir(unzipped_dir)}')
            self._move_to_parent_dir(unzipped_dir)
            os.remove(local_name)
            os.removedirs(unzipped_dir)
        return True

    @staticmethod
    def _move_to_parent_dir(dirname):
        dst_dir = os.path.split(dirname)[0]
        for f in os.listdir(dirname):
            os.rename(os.path.join(dirname, f), os.path.join(dst_dir, f))

    def __del__(self):
        # WARNING! In current version of library the logout function does not work (session is not closed)
        self.client.logout()

    # TODO: more, according to needs, e.g.
    def read_file(self, remote_path):
        pass

    def write_file(self, file, remote_dir):
        pass