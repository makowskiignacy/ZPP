import os
import logging
from zipfile import ZipFile

from mlplatformclient.custom_exceptions import InvalidArgumentError

logger = logging.getLogger(__name__)


def unzip(source_path_file: str, destination_path: str) -> bool:
    """
    Unpack file from source_path_file to destination_path

    :param: source_path_file: Source path to zip file.
    :param: destination_path: Destination path where the file will be unpacked.
    :return: bool: True if file is unpacked
    """
    if os.path.isfile(source_path_file):
        destination_path = os.path.abspath(destination_path)
        if not os.path.exists(destination_path):
            os.makedirs(destination_path)
        with ZipFile(source_path_file, 'r') as zip_file:
            zip_file.extractall(destination_path)
            logger.info(f"File is unzipped in {destination_path}")
            return True
    raise InvalidArgumentError(f"Source file path argument: {source_path_file} in unzip() is invalid.")
