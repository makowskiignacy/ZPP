from functools import wraps

import requests
from requests.exceptions import ConnectionError
from typing import Callable

from mlplatformclient.custom_exceptions import ExternalServiceConnectionError


def handle_connection_error(service: str) -> Callable:
    """
    Raises `ExternalServiceConnectionError` after catching the `ConnectionError` while
    attempting to connect with RPD service.

    :param service: service name
    :raises: ExternalServiceConnectionError
    """
    def decorator(fn) -> Callable:
        @wraps(fn)
        def wrapper(*args, **kwargs) -> requests.Response:
            try:
                return fn(*args, **kwargs)
            except ConnectionError as e:
                raise ExternalServiceConnectionError(f'{service} service is temporarily unavailable due to: {e}')
        return wrapper
    return decorator
