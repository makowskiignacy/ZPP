# mlplatformlib

Library of ML models. [source of code](https://gitlab.cbitt.nask.pl/zis/ml-platform-lib) is on gitlab.

### Generate package and install locally

- Install `requirements.txt`
  ```
  source .env
  export PIP_EXTRA_INDEX_URL
  pip install -r requirements.txt
  ```
- Run `sh generate_package_locally.sh`
- Install package from `*.tar.gz` file:
  ```
  pip install <package_name>.tar.gz
  ```

### Generate and register package from any branch (gitlab-ci)

- Set CI/CD environment variables `PACKAGE_REGISTRY_TOKEN_NAME` and `PACKAGE_REGISTRY_TOKEN` to Deploy Token `Username` and `Password` [(documentation)](https://docs.gitlab.com/ee/user/project/deploy_tokens/index.html)
- Set package version (`pyproject.toml -> [project] -> version`)
- Push to gitlab (origin)
- Build Gitlab CI

### Install package from terminal by terminal from Gitlab Package Registry

- Install using pip:
  ```
  pip install mlplatformlib~=<version> --extra-index-url https://ro-package-registry:6iUfs-yTK8yzBkW6yyPU@gitlab.cbitt.nask.pl/api/v4/projects/191/packages/pypi/simple
  ```

### Install package by requirements.txt file from Gitlab Package Registry

- Set environment variables `PIP_EXTRA_INDEX_URL` with following code:
  ```
  export PIP_EXTRA_INDEX_URL="https://ro-package-registry:6iUfs-yTK8yzBkW6yyPU@gitlab.cbitt.nask.pl/api/v4/projects/191/packages/pypi/simple"
  ```
- Add following code to requirements.txt file (remember to set package version!):
  ```
  mlplatformlib~=<version>
  ```
- `pip install -r requirements.txt`