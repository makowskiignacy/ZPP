import logging
import numpy as np

from mlplatformlib.model_building.base_model import BaseNonEpochModel

from sklearn.ensemble import GradientBoostingClassifier as sk_GradientBoostingClassifier

logger = logging.getLogger('nni_experiment')


class GradientBoostingClassifier(BaseNonEpochModel):
    def __init__(self, X: np.ndarray, y: np.ndarray, threshold: float = 0.5, loss='log_loss', learning_rate=0.1,
                 n_estimators=100, subsample=1.0, criterion='friedman_mse', min_samples_split=2, min_samples_leaf=1,
                 min_weight_fraction_leaf=0.0, max_depth=3, min_impurity_decrease=0.0, init=None, random_state=None,
                 max_features=None, verbose=0, max_leaf_nodes=None, warm_start=False, validation_fraction=0.1,
                 n_iter_no_change=None, tol=0.0001, ccp_alpha=0.0):
        super(GradientBoostingClassifier, self).__init__(X=X, y=y, threshold=threshold)
        self.model = sk_GradientBoostingClassifier(loss=loss, learning_rate=learning_rate, n_estimators=n_estimators,
                                                   subsample=subsample, criterion=criterion,
                                                   min_samples_split=min_samples_split,
                                                   min_samples_leaf=min_samples_leaf,
                                                   min_weight_fraction_leaf=min_weight_fraction_leaf,
                                                   max_depth=max_depth, min_impurity_decrease=min_impurity_decrease,
                                                   init=init, random_state=random_state, max_features=max_features,
                                                   verbose=verbose, max_leaf_nodes=max_leaf_nodes,
                                                   warm_start=warm_start, validation_fraction=validation_fraction,
                                                   n_iter_no_change=n_iter_no_change, tol=tol, ccp_alpha=ccp_alpha)

    def fit(self):
        self.model.fit(self.X, self.y)

    def predict(self, X: np.ndarray) -> np.array:
        return self.model.predict(X)

    def get_sklearn_object(self, threshold: float = 0.5) -> sk_GradientBoostingClassifier:
        """
        The method set declared threshold for model (default value of threshold = 0.5).
        """
        self.threshold = threshold
        self.model.threshold = threshold
        return self.model
