import copy
import logging

import numpy as np
import torch
from torch import nn, optim
from torch.utils.data import DataLoader, TensorDataset
from skorch import NeuralNetBinaryClassifier

from mlplatformlib.model_building.base_model import BaseEpochModel

logger = logging.getLogger('nni_experiment')


def binary_acc(y_pred, y_test):
    y_pred_tag = torch.round(torch.sigmoid(y_pred))

    correct_results_sum = (y_pred_tag == y_test).sum().float()
    acc = correct_results_sum / y_test.shape[0]
    acc = torch.round(acc * 100)

    return acc


class BinaryNeuralNetworkClassifier(nn.Module, BaseEpochModel):
    def __init__(self,
                 X: np.ndarray, y: np.ndarray, threshold: float = 0.5,
                 hidden_size_1=128,
                 hidden_size_2=128,
                 # dropout attribute must be float type, not int
                 dropout=0.0, lr=0.01,
                 momentum=0.1,
                 no_cuda=True,
                 batch_size=128):
        nn.Module.__init__(self)
        BaseEpochModel.__init__(self, X, y, threshold)
        self.batch_size = batch_size
        self.train_loader = DataLoader(TensorDataset(torch.Tensor(X), torch.Tensor(y)), self.batch_size)
        input_size = X.shape[1]
        # TODO: where to use momentum?
        self.layer_1 = nn.Linear(input_size, hidden_size_1)  # input size needs to be same as number of features
        self.layer_2 = nn.Linear(hidden_size_1, hidden_size_2)
        self.layer_out = nn.Linear(hidden_size_2, 1)

        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(p=dropout)
        self.batchnorm1 = nn.BatchNorm1d(hidden_size_1)
        self.batchnorm2 = nn.BatchNorm1d(hidden_size_2)
        self.optimizer = optim.Adam(self.parameters(), lr=lr)
        self.device = torch.device("cuda:0" if torch.cuda.is_available() and not no_cuda else "cpu")
        self.to(self.device)

    def forward(self, inputs):
        x = self.relu(self.layer_1(inputs))
        x = self.batchnorm1(x)
        x = self.relu(self.layer_2(x))
        x = self.batchnorm2(x)
        x = self.dropout(x)
        x = self.layer_out(x)
        x = torch.sigmoid(x)
        return x

    def fit_epoch(self):
        self.train()
        # epoch_loss = 0
        # epoch_acc = 0
        for batch_idx, (data, target) in enumerate(self.train_loader):
            data, target = data.to(self.device), target.to(self.device)
            self.optimizer.zero_grad()
            output = self(data)
            loss = nn.BCELoss()(output, target.unsqueeze(1))
            # acc = binary_acc(output, target.unsqueeze(1))
            # writer.add_scalar('Loss/train', loss, epoch) #TODO - tensorboard
            loss.backward()
            self.optimizer.step()

    def predict(self, X: np.ndarray) -> np.ndarray:
        self.eval()
        with torch.no_grad():
            pred = self.forward(torch.Tensor(X).to(self.device))
            return pred.cpu().numpy().flatten()

    def get_sklearn_object(self, threshold: float = 0.5) -> NeuralNetBinaryClassifier:
        """
        Skorch class is required for the neural network to be placed inside sklearn pipeline.
        The method set declared threshold for model (default value of threshold = 0.5).
        """
        self.threshold = threshold
        model = copy.deepcopy(self)
        model.X = None
        model.y = None
        model.train_loader = None
        net = NeuralNetBinaryClassifier(model,
                                        predict_nonlinearity=lambda x: torch.stack((1 - x, x), 1),
                                        threshold=threshold)
        net.initialize()
        return net
