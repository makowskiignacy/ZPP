import logging

import numpy as np

from mlplatformlib.model_building.base_model import BaseNonEpochModel

from sklearn.tree import DecisionTreeClassifier as sk_DecisionTreeClassifier

logger = logging.getLogger('nni_experiment')


class DecisionTreeClassifier(BaseNonEpochModel):
    def __init__(self, X: np.ndarray, y: np.ndarray, threshold: float = 0.5, criterion='gini', splitter='best',
                 max_depth=None, min_samples_split=2, min_samples_leaf=1, min_weight_fraction_leaf=0.0, max_features=None,
                 random_state=None, max_leaf_nodes=None, min_impurity_decrease=0.0, class_weight=None, ccp_alpha=0.0):
        super(DecisionTreeClassifier, self).__init__(X=X, y=y, threshold=threshold)
        self.model = sk_DecisionTreeClassifier(criterion=criterion, splitter=splitter, max_depth=max_depth,
                                               min_samples_split=min_samples_split, min_samples_leaf=min_samples_leaf,
                                               min_weight_fraction_leaf=min_weight_fraction_leaf,
                                               max_features=max_features, random_state=random_state,
                                               max_leaf_nodes=max_leaf_nodes, ccp_alpha=ccp_alpha,
                                               min_impurity_decrease=min_impurity_decrease, class_weight=class_weight
                                               )

    def fit(self):
        self.model.fit(self.X, self.y)

    def predict(self, X: np.ndarray) -> np.array:
        return self.model.predict(X)

    def get_sklearn_object(self, threshold: float = 0.5) -> sk_DecisionTreeClassifier:
        """
        The method set declared threshold for model (default value of threshold = 0.5).
        """
        self.threshold = threshold
        self.model.threshold = threshold
        return self.model
