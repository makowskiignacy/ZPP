import logging
from abc import ABC

import numpy as np

logger = logging.getLogger(__name__)


class BaseModelBuilder(ABC):
    """
    Base class for model builder. ModelBuilder must provide `train` and `predict` methods.
    """
    def fit(self, X: np.ndarray, y: np.ndarray, reporters):
        ...

    def predict(self, X: np.ndarray) -> np.ndarray:
        ...

    def get_sklearn_object(self):
        ...
