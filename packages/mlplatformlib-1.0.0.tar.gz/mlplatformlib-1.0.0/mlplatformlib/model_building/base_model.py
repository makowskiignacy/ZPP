from abc import ABC

import numpy as np


class BaseModel(ABC):
    def __init__(self, X, y, threshold):
        self.X = X
        self.y = y
        self.threshold = threshold

    def predict(self, X: np.ndarray) -> np.ndarray:
        ...

    def get_sklearn_object(self):
        ...


class BaseEpochModel(BaseModel):
    def fit_epoch(self):
        ...


class BaseNonEpochModel(BaseModel):
    def fit(self):
        ...
