import numpy as np
from sklearn.decomposition import PCA as sk_PCA

from mlplatformlib.preprocessing.base_element import BaseModelStructure


class PCA(BaseModelStructure):

    def __init__(self, n_components=0, svd_solver='auto', tol=0.0, iterated_power='auto', random_state=None) -> None:
        super(BaseModelStructure, self).__init__()
        self.model = sk_PCA(n_components=n_components, svd_solver=svd_solver, tol=tol, iterated_power=iterated_power,
                            random_state=random_state)

    def fit(self, X: np.ndarray, y: np.ndarray):
        self.model.fit(X, y)

    def fit_transform(self, X: np.ndarray, y: np.ndarray) -> np.ndarray:
        return self.model.fit_transform(X, y)

    def transform(self, X: np.ndarray) -> np.ndarray:
        return self.model.transform(X)

    def get_sklearn_object(self):
        return self.model
