import numpy as np
from sklearn.base import BaseEstimator
from sklearn.preprocessing import RobustScaler as sk_RobustScaler

from mlplatformlib.preprocessing.base_element import BaseModelStructure


class RobustScaler(BaseModelStructure):
    def __init__(self) -> None:
        self.model = sk_RobustScaler()

    def fit(self, X: np.ndarray, y: np.ndarray) -> None:
        self.model.fit(X, y)

    def fit_transform(self, X: np.ndarray, y: np.ndarray) -> np.ndarray:
        return self.model.fit_transform(X, y)

    def transform(self, X: np.ndarray) -> np.ndarray:
        return self.model.transform(X)

    def get_sklearn_object(self) -> BaseEstimator:
        return self.model
