from abc import ABC

import numpy as np


class BaseModelStructure(ABC):

    def fit(self, X: np.ndarray, y: np.ndarray):
        ...

    def fit_transform(self, X: np.ndarray, y: np.ndarray) -> np.ndarray:
        ...

    def transform(self, X: np.ndarray) -> np.ndarray:
        ...

    def get_sklearn_object(self):
        ...
