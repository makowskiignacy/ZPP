import logging

import numpy as np

from mlplatformlib.model_building.base_model import BaseNonEpochModel, BaseEpochModel

logger = logging.getLogger('nni_experiment')


class BinaryMockClassifier(BaseNonEpochModel):
    def __init__(self, X: np.ndarray, y: np.ndarray, threshold: float = 0.5, randomizer=0):
        super(BinaryMockClassifier, self).__init__(X=X, y=y, threshold=threshold)
        self.randomizer = randomizer

    def fit(self):
        pass

    def predict(self, data: np.ndarray) -> np.ndarray:
        prediction = data.mean(axis=1)
        randomized_prediction = prediction * (1-self.randomizer) + self.randomizer * np.random.random(prediction.shape)
        return randomized_prediction

    def get_sklearn_object(self, threshold: float = 0.5):
        self.threshold = threshold
        return self

class EpochBinaryMockClassifier(BaseEpochModel):
    def __init__(self, X: np.ndarray, y: np.ndarray, threshold: float = 0.5, randomizer=0, lr=1):
        super(BaseEpochModel, self).__init__(X=X, y=y, threshold=threshold)
        self.randomizer = randomizer
        self.epoch = 0
        self.lr = lr

    def fit_epoch(self):
        self.epoch += 1
        pass

    def predict(self, data: np.ndarray) -> np.ndarray:
        prediction = data.mean(axis=1)
        randomizer = self.randomizer / (1+self.epoch * self.lr)
        randomized_prediction = prediction * (1-randomizer) + randomizer * np.random.random(prediction.shape)
        # return (randomized_prediction > 0.5).astype(int)
        return randomized_prediction

    def get_sklearn_object(self, threshold: float = 0.5):
        self.threshold = threshold
        return self
