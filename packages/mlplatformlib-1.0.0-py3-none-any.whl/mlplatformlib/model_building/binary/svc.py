import logging

import numpy as np

from mlplatformlib.model_building.base_model import BaseNonEpochModel

from sklearn.svm import SVC as sk_SupportVectorClassification

logger = logging.getLogger('nni_experiment')


class SVCClassifier(BaseNonEpochModel):
    def __init__(self, X: np.ndarray, y: np.ndarray, threshold: float = 0.5, C=1.0, kernel='rbf', degree=3,
                 gamma='scale', coef0=0.0, shrinking=True, probability=False, tol=0.001, cache_size=200,
                 class_weight=None, verbose=False, max_iter=-1, decision_function_shape='ovr', break_ties=False,
                 random_state=None):
        super(SVCClassifier, self).__init__(X=X, y=y, threshold=threshold)
        self.model = sk_SupportVectorClassification(C=C, kernel=kernel, degree=degree, gamma=gamma, coef0=coef0,
                                                    shrinking=shrinking, probability=probability, tol=tol,
                                                    cache_size=cache_size, class_weight=class_weight, verbose=verbose,
                                                    max_iter=max_iter, decision_function_shape=decision_function_shape,
                                                    break_ties=break_ties, random_state=random_state)

    def fit(self):
        self.model.fit(self.X, self.y)

    def predict(self, X: np.ndarray) -> np.array:
        return self.model.predict(X)

    def get_sklearn_object(self, threshold: float = 0.5) -> sk_SupportVectorClassification:
        """
        The method set declared threshold for model (default value of threshold = 0.5).
        """
        self.threshold = threshold
        self.model.threshold = threshold
        return self.model
