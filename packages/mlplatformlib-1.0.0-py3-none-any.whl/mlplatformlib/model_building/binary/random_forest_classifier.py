import logging

import numpy as np
from sklearn.ensemble import RandomForestClassifier as sk_RandomForestClassifier

from mlplatformlib.model_building.base_model import BaseNonEpochModel

logger = logging.getLogger('nni_experiment')


class RandomForestClassifier(BaseNonEpochModel):
    def __init__(self, X: np.ndarray, y: np.ndarray, threshold: float = 0.5, n_estimators=100, *args, **kwargs) -> None:
        super().__init__(X=X, y=y, threshold=threshold)
        self.model = sk_RandomForestClassifier(n_estimators=n_estimators, *args, **kwargs)

    def fit(self) -> None:
        self.model.fit(self.X, self.y)

    def predict(self, X: np.ndarray) -> np.array:
        return self.model.predict(X)

    def get_sklearn_object(self, threshold: float = 0.5) -> sk_RandomForestClassifier:
        """
        The method set declared threshold for model (default value of threshold = 0.5).
        """
        self.threshold = threshold
        self.model.threshold = threshold
        return self.model
